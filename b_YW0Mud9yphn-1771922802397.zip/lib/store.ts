"use client";

import { useSyncExternalStore, useCallback } from "react";

// Generic event-driven store
type Listener = () => void;

function createStore<T>(initialState: T) {
  let state = initialState;
  const listeners = new Set<Listener>();

  function getState() {
    return state;
  }

  function setState(updater: T | ((prev: T) => T)) {
    state = typeof updater === "function" ? (updater as (prev: T) => T)(state) : updater;
    listeners.forEach((l) => l());
    // Persist to sessionStorage
    try {
      if (typeof window !== "undefined") {
        sessionStorage.setItem("tripAppState", JSON.stringify(state));
      }
    } catch {}
  }

  function subscribe(listener: Listener) {
    listeners.add(listener);
    return () => listeners.delete(listener);
  }

  // Hydrate from sessionStorage
  if (typeof window !== "undefined") {
    try {
      const saved = sessionStorage.getItem("tripAppState");
      if (saved) {
        state = { ...initialState, ...JSON.parse(saved) };
      }
    } catch {}
  }

  return { getState, setState, subscribe };
}

// App State Types
export interface ChecklistItem {
  id: string;
  text: string;
  completed: boolean;
  assignee: string;
  createdAt: string;
}

export interface PackingItem {
  id: string;
  item: string;
  packed: boolean;
  userId: string;
}

export interface ExpenseItem {
  id: string;
  description: string;
  amount: number;
  paidBy: string;
  splitWith: string[];
  date: string;
}

export interface ChatMessage {
  id: string;
  userId: string;
  userName: string;
  text: string;
  timestamp: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  author: string;
  updatedAt: string;
}

export interface MediaItem {
  id: string;
  url: string;
  type: "photo" | "video";
  caption: string;
  uploadedBy: string;
  uploadedAt: string;
}

export interface ActivityLog {
  id: string;
  action: string;
  user: string;
  timestamp: string;
}

export interface AppState {
  currentUser: string | null;
  checklist: ChecklistItem[];
  packing: Record<string, PackingItem[]>;
  expenses: ExpenseItem[];
  messages: ChatMessage[];
  notes: Note[];
  media: MediaItem[];
  activityLog: ActivityLog[];
  activeTab: string;
}

const initialState: AppState = {
  currentUser: null,
  checklist: [
    { id: "c1", text: "Book return tickets", completed: true, assignee: "akhil", createdAt: "2026-01-15" },
    { id: "c2", text: "Pack medicines and first aid kit", completed: false, assignee: "pratham", createdAt: "2026-01-20" },
    { id: "c3", text: "Arrange offline maps for Katra", completed: false, assignee: "aniket", createdAt: "2026-02-01" },
    { id: "c4", text: "Confirm hotel booking near temple", completed: true, assignee: "akhil", createdAt: "2026-02-05" },
    { id: "c5", text: "Get trek shoes ready", completed: false, assignee: "pratham", createdAt: "2026-02-10" },
    { id: "c6", text: "Pack warm jackets", completed: false, assignee: "aniket", createdAt: "2026-02-12" },
    { id: "c7", text: "Carry power bank and chargers", completed: false, assignee: "akhil", createdAt: "2026-02-15" },
    { id: "c8", text: "Book yatra slip online", completed: true, assignee: "pratham", createdAt: "2026-02-18" },
  ],
  packing: {
    akhil: [
      { id: "p1", item: "ID Proof (Aadhar/PAN)", packed: true, userId: "akhil" },
      { id: "p2", item: "Train ticket printout", packed: true, userId: "akhil" },
      { id: "p3", item: "Warm jacket", packed: false, userId: "akhil" },
      { id: "p4", item: "Trek shoes", packed: false, userId: "akhil" },
      { id: "p5", item: "Water bottle", packed: false, userId: "akhil" },
      { id: "p6", item: "Power bank", packed: true, userId: "akhil" },
    ],
    pratham: [
      { id: "p7", item: "ID Proof", packed: true, userId: "pratham" },
      { id: "p8", item: "Medicines & first aid", packed: false, userId: "pratham" },
      { id: "p9", item: "Raincoat", packed: false, userId: "pratham" },
      { id: "p10", item: "Snacks for train", packed: false, userId: "pratham" },
      { id: "p11", item: "Extra clothes", packed: false, userId: "pratham" },
    ],
    aniket: [
      { id: "p12", item: "ID Proof", packed: true, userId: "aniket" },
      { id: "p13", item: "Camera", packed: false, userId: "aniket" },
      { id: "p14", item: "Offline maps downloaded", packed: false, userId: "aniket" },
      { id: "p15", item: "Torch/flashlight", packed: false, userId: "aniket" },
      { id: "p16", item: "Warm socks", packed: false, userId: "aniket" },
    ],
  },
  expenses: [
    { id: "e1", description: "Train tickets (IRCTC)", amount: 973.15, paidBy: "akhil", splitWith: ["akhil", "pratham", "aniket"], date: "2026-01-12" },
    { id: "e2", description: "Hotel booking advance", amount: 2500, paidBy: "pratham", splitWith: ["akhil", "pratham", "aniket"], date: "2026-02-05" },
  ],
  messages: [
    { id: "m1", userId: "akhil", userName: "AKHIL", text: "Tickets are booked! PNR: 2944875853", timestamp: "2026-01-12T10:30:00" },
    { id: "m2", userId: "pratham", userName: "PRATHAM", text: "Great! All confirmed. Let's start planning the packing list.", timestamp: "2026-01-12T11:00:00" },
    { id: "m3", userId: "aniket", userName: "ANIKET", text: "I'll handle the maps and route planning for Vaishno Devi trek.", timestamp: "2026-01-12T11:15:00" },
    { id: "m4", userId: "akhil", userName: "AKHIL", text: "Hotel near Katra is booked. Check-in after we reach.", timestamp: "2026-02-05T09:00:00" },
    { id: "m5", userId: "pratham", userName: "PRATHAM", text: "Don't forget warm clothes, it'll be cold in March!", timestamp: "2026-02-10T14:00:00" },
  ],
  notes: [
    {
      id: "n1",
      title: "Vaishno Devi Trek Info",
      content:
        "Trek distance: ~13 km one way. Start early morning. Carry water and snacks. Ponies/helicopters available. Required: Yatra slip (book online at maavaishnodevi.org). Temple timings: 5 AM - 12 PM, 4 PM - 9 PM.",
      author: "aniket",
      updatedAt: "2026-02-01",
    },
    {
      id: "n2",
      title: "Emergency Contacts",
      content: "Katra Police: 01991-232066\nSMVD Shrine Board: 01991-234037\nHelicopter Booking: 9419-104055\nNearest Hospital: Shri Mata Vaishno Devi Narayana Hospital",
      author: "akhil",
      updatedAt: "2026-02-08",
    },
  ],
  media: [],
  activityLog: [
    { id: "a1", action: "Booked train tickets", user: "akhil", timestamp: "2026-01-12T10:00:00" },
    { id: "a2", action: "Added hotel booking expense", user: "pratham", timestamp: "2026-02-05T09:00:00" },
    { id: "a3", action: "Created trek info note", user: "aniket", timestamp: "2026-02-01T12:00:00" },
  ],
  activeTab: "dashboard",
};

export const appStore = createStore<AppState>(initialState);

// React hook
export function useAppState(): [AppState, (updater: AppState | ((prev: AppState) => AppState)) => void] {
  const state = useSyncExternalStore(appStore.subscribe, appStore.getState, () => initialState);
  return [state, appStore.setState];
}

// Helper to generate IDs
export function generateId(): string {
  return Math.random().toString(36).substring(2, 11) + Date.now().toString(36);
}

// Helper to add activity log
export function logActivity(action: string, user: string) {
  appStore.setState((prev) => ({
    ...prev,
    activityLog: [
      { id: generateId(), action, user, timestamp: new Date().toISOString() },
      ...prev.activityLog,
    ].slice(0, 50),
  }));
}
