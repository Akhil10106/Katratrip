"use client";

import { useAppState } from "@/lib/store";
import { TRIP_DATA } from "@/lib/trip-data";
import { Activity } from "lucide-react";

export function ActivityFeed() {
  const [state] = useAppState();
  const logs = state.activityLog.slice(0, 8);

  return (
    <div className="bg-card border border-border rounded-2xl p-6">
      <div className="flex items-center gap-2 mb-5">
        <Activity className="w-4 h-4 text-primary" />
        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Recent Activity
        </span>
      </div>

      <div className="flex flex-col gap-3">
        {logs.map((log) => {
          const passenger = TRIP_DATA.passengers.find((p) => p.id === log.user);
          return (
            <div key={log.id} className="flex items-start gap-3">
              <div className={`w-7 h-7 rounded-lg ${passenger?.color ?? "bg-muted"} flex items-center justify-center text-[10px] font-bold text-primary-foreground shrink-0 mt-0.5`}>
                {passenger?.avatar ?? "?"}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-foreground">
                  <span className="font-medium">{passenger?.name ?? log.user}</span>{" "}
                  <span className="text-muted-foreground">{log.action}</span>
                </p>
                <p className="text-[10px] text-muted-foreground mt-0.5">
                  {formatRelativeTime(log.timestamp)}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function formatRelativeTime(ts: string): string {
  const date = new Date(ts);
  return date.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}
