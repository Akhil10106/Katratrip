"use client";

import { useAppState } from "@/lib/store";
import { TRIP_DATA } from "@/lib/trip-data";
import {
  LayoutDashboard,
  CheckSquare,
  MessageSquare,
  Image,
  Train,
  LogOut,
  DollarSign,
  StickyNote,
  Menu,
  X,
} from "lucide-react";
import { useState, useCallback, useEffect, useRef } from "react";

const tabs = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "planning", label: "Planning", icon: CheckSquare },
  { id: "expenses", label: "Expenses", icon: DollarSign },
  { id: "chat", label: "Chat", icon: MessageSquare },
  { id: "notes", label: "Notes", icon: StickyNote },
  { id: "media", label: "Media", icon: Image },
];

export function AppNavigation() {
  const [state, setState] = useAppState();
  const [mobileOpen, setMobileOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const currentPassenger = TRIP_DATA.passengers.find((p) => p.id === state.currentUser);

  const handleTabChange = useCallback((tabId: string) => {
    setState((prev) => ({ ...prev, activeTab: tabId }));
    setMobileOpen(false);
  }, [setState]);

  const handleLogout = useCallback(() => {
    setState((prev) => ({ ...prev, currentUser: null, activeTab: "dashboard" }));
  }, [setState]);

  // Close mobile menu on outside click
  useEffect(() => {
    if (!mobileOpen) return;
    function handleClick(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMobileOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [mobileOpen]);

  // Close mobile menu on escape key
  useEffect(() => {
    if (!mobileOpen) return;
    function handleKey(e: KeyboardEvent) {
      if (e.key === "Escape") setMobileOpen(false);
    }
    document.addEventListener("keydown", handleKey);
    return () => document.removeEventListener("keydown", handleKey);
  }, [mobileOpen]);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-64 shrink-0 bg-card border-r border-border h-[100dvh] sticky top-0">
        {/* Brand */}
        <div className="p-5 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center">
              <Train className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-foreground tracking-tight">TripSync</h1>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">
                {TRIP_DATA.journey.from.code} &rarr; {TRIP_DATA.journey.to.code}
              </p>
            </div>
          </div>
        </div>

        {/* Nav items */}
        <nav className="flex-1 p-3 flex flex-col gap-1 overflow-y-auto" role="navigation" aria-label="Main navigation">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = state.activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => handleTabChange(tab.id)}
                aria-current={isActive ? "page" : undefined}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
                  isActive
                    ? "bg-primary/10 text-primary border border-primary/20"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary/50 border border-transparent"
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{tab.label}</span>
                {tab.id === "chat" && state.messages.length > 0 && (
                  <span className="ml-auto text-[10px] bg-primary/20 text-primary px-1.5 py-0.5 rounded-full shrink-0">
                    {state.messages.length}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* User footer */}
        <div className="p-4 border-t border-border">
          <div className="flex items-center gap-3 mb-3">
            <div className={`w-8 h-8 rounded-lg ${currentPassenger?.color} flex items-center justify-center text-xs font-bold text-primary-foreground shrink-0`}>
              {currentPassenger?.avatar}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-foreground truncate">{currentPassenger?.name}</p>
              <p className="text-[10px] text-muted-foreground">
                {currentPassenger?.coach}/{currentPassenger?.berth}
              </p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-medium text-muted-foreground hover:text-destructive hover:bg-destructive/10 border border-border transition-all"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="lg:hidden fixed top-0 left-0 right-0 z-50 bg-card/80 backdrop-blur-xl border-b border-border" ref={menuRef}>
        <div className="flex items-center justify-between px-4 h-14">
          <div className="flex items-center gap-2">
            <Train className="w-5 h-5 text-primary" />
            <span className="text-sm font-bold text-foreground">TripSync</span>
          </div>
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="p-2 text-foreground touch-manipulation"
            aria-expanded={mobileOpen}
            aria-label={mobileOpen ? "Close menu" : "Open menu"}
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="animate-in fade-in slide-in-from-top-2 duration-200 bg-card border-b border-border p-4 max-h-[calc(100dvh-3.5rem)] overflow-y-auto">
            <nav className="flex flex-col gap-1" role="navigation" aria-label="Mobile navigation">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                const isActive = state.activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => handleTabChange(tab.id)}
                    aria-current={isActive ? "page" : undefined}
                    className={`flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-medium transition-all touch-manipulation ${
                      isActive
                        ? "bg-primary/10 text-primary"
                        : "text-muted-foreground hover:text-foreground active:bg-secondary/30"
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    {tab.label}
                    {tab.id === "chat" && state.messages.length > 0 && (
                      <span className="ml-auto text-[10px] bg-primary/20 text-primary px-1.5 py-0.5 rounded-full">
                        {state.messages.length}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
            <div className="flex items-center gap-3 mt-3 pt-3 border-t border-border">
              <div className={`w-8 h-8 rounded-lg ${currentPassenger?.color} flex items-center justify-center text-xs font-bold text-primary-foreground shrink-0`}>
                {currentPassenger?.avatar}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-foreground truncate">{currentPassenger?.name}</p>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium text-destructive bg-destructive/10 touch-manipulation shrink-0"
              >
                <LogOut className="w-3.5 h-3.5" />
                Sign Out
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Mobile menu backdrop */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 z-40 bg-background/60 backdrop-blur-sm"
          aria-hidden="true"
          onClick={() => setMobileOpen(false)}
        />
      )}
    </>
  );
}
