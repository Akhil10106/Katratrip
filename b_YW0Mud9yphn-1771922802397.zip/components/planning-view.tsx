"use client";

import { useState } from "react";
import { useAppState, generateId, logActivity } from "@/lib/store";
import { TRIP_DATA } from "@/lib/trip-data";
import {
  CheckSquare,
  Plus,
  Package,
  Check,
  Trash2,
  User,
  ChevronDown,
  ChevronRight,
} from "lucide-react";
import { toast } from "sonner";

export function PlanningView() {
  const [activeSection, setActiveSection] = useState<"checklist" | "packing">("checklist");

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Trip Planning</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Organize your trip preparation with shared checklists and packing lists.
        </p>
      </div>

      {/* Section toggle */}
      <div className="flex gap-2 overflow-x-auto">
        <button
          onClick={() => setActiveSection("checklist")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all touch-manipulation shrink-0 ${
            activeSection === "checklist"
              ? "bg-primary/10 text-primary border border-primary/20"
              : "bg-secondary/30 text-muted-foreground border border-border hover:text-foreground active:bg-secondary/50"
          }`}
        >
          <CheckSquare className="w-4 h-4 shrink-0" />
          Shared Checklist
        </button>
        <button
          onClick={() => setActiveSection("packing")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all touch-manipulation shrink-0 ${
            activeSection === "packing"
              ? "bg-primary/10 text-primary border border-primary/20"
              : "bg-secondary/30 text-muted-foreground border border-border hover:text-foreground active:bg-secondary/50"
          }`}
        >
          <Package className="w-4 h-4 shrink-0" />
          Packing Planner
        </button>
      </div>

      {activeSection === "checklist" ? <SharedChecklist /> : <PackingPlanner />}
    </div>
  );
}

function SharedChecklist() {
  const [state, setState] = useAppState();
  const [newTask, setNewTask] = useState("");
  const [newAssignee, setNewAssignee] = useState(state.currentUser ?? "akhil");

  const done = state.checklist.filter((c) => c.completed).length;
  const total = state.checklist.length;
  const progress = total > 0 ? (done / total) * 100 : 0;

  function addTask() {
    if (!newTask.trim()) return;
    setState((prev) => ({
      ...prev,
      checklist: [
        ...prev.checklist,
        {
          id: generateId(),
          text: newTask.trim(),
          completed: false,
          assignee: newAssignee,
          createdAt: new Date().toISOString().split("T")[0],
        },
      ],
    }));
    logActivity(`Added task: ${newTask.trim()}`, state.currentUser!);
    toast.success("Task added");
    setNewTask("");
  }

  function toggleTask(id: string) {
    setState((prev) => ({
      ...prev,
      checklist: prev.checklist.map((c) =>
        c.id === id ? { ...c, completed: !c.completed } : c
      ),
    }));
  }

  function deleteTask(id: string) {
    setState((prev) => ({
      ...prev,
      checklist: prev.checklist.filter((c) => c.id !== id),
    }));
    toast.success("Task removed");
  }

  return (
    <div className="bg-card border border-border rounded-2xl p-6">
      {/* Progress bar */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            Progress
          </span>
          <span className="text-sm font-bold text-foreground">
            {done}/{total} complete
          </span>
        </div>
        <div className="h-2 bg-secondary/50 rounded-full overflow-hidden">
          <div
            className="h-full bg-primary rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Add new task */}
      <div className="flex flex-col sm:flex-row gap-2 mb-6">
        <input
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && addTask()}
          placeholder="Add a new task..."
          className="flex-1 bg-secondary/30 border border-border rounded-xl px-4 py-2.5 text-base sm:text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
        />
        <div className="flex gap-2">
          <select
            value={newAssignee}
            onChange={(e) => setNewAssignee(e.target.value)}
            className="flex-1 sm:flex-none bg-secondary/30 border border-border rounded-xl px-3 py-2.5 text-base sm:text-sm text-foreground focus:outline-none focus:border-primary transition-colors"
          >
            {TRIP_DATA.passengers.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name.split(" ")[0]}
              </option>
            ))}
          </select>
          <button
            onClick={addTask}
            className="px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-all flex items-center gap-1.5 touch-manipulation active:scale-95 shrink-0"
          >
            <Plus className="w-4 h-4" />
            Add
          </button>
        </div>
      </div>

      {/* Task list */}
      <div className="flex flex-col gap-2">
        {state.checklist.map((task) => {
          const assignee = TRIP_DATA.passengers.find((p) => p.id === task.assignee);
          return (
            <div
              key={task.id}
              className={`flex items-center gap-2 sm:gap-3 p-3 rounded-xl border transition-all ${
                task.completed
                  ? "border-border/50 bg-secondary/10 opacity-60"
                  : "border-border bg-secondary/20"
              }`}
            >
              <button
                onClick={() => toggleTask(task.id)}
                className={`w-5 h-5 rounded-md border-2 flex items-center justify-center shrink-0 transition-all touch-manipulation ${
                  task.completed
                    ? "bg-primary border-primary"
                    : "border-muted-foreground/30 hover:border-primary"
                }`}
              >
                {task.completed && <Check className="w-3 h-3 text-primary-foreground" />}
              </button>
              <span
                className={`flex-1 text-sm min-w-0 break-words ${
                  task.completed ? "line-through text-muted-foreground" : "text-foreground"
                }`}
              >
                {task.text}
              </span>
              <div className={`w-6 h-6 rounded-md ${assignee?.color ?? "bg-muted"} flex items-center justify-center shrink-0`}>
                <span className="text-[9px] font-bold text-primary-foreground">
                  {assignee?.avatar?.charAt(0)}
                </span>
              </div>
              <button
                onClick={() => deleteTask(task.id)}
                className="p-1.5 text-muted-foreground hover:text-destructive transition-colors shrink-0 touch-manipulation"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function PackingPlanner() {
  const [state, setState] = useAppState();
  const [expandedUsers, setExpandedUsers] = useState<string[]>(
    TRIP_DATA.passengers.map((p) => p.id)
  );
  const [newItemText, setNewItemText] = useState<Record<string, string>>({});

  function toggleExpand(userId: string) {
    setExpandedUsers((prev) =>
      prev.includes(userId) ? prev.filter((id) => id !== userId) : [...prev, userId]
    );
  }

  function togglePacked(userId: string, itemId: string) {
    setState((prev) => ({
      ...prev,
      packing: {
        ...prev.packing,
        [userId]: prev.packing[userId].map((item) =>
          item.id === itemId ? { ...item, packed: !item.packed } : item
        ),
      },
    }));
  }

  function addItem(userId: string) {
    const text = newItemText[userId]?.trim();
    if (!text) return;
    setState((prev) => ({
      ...prev,
      packing: {
        ...prev.packing,
        [userId]: [
          ...(prev.packing[userId] ?? []),
          { id: generateId(), item: text, packed: false, userId },
        ],
      },
    }));
    setNewItemText((prev) => ({ ...prev, [userId]: "" }));
    toast.success("Item added to packing list");
  }

  function deleteItem(userId: string, itemId: string) {
    setState((prev) => ({
      ...prev,
      packing: {
        ...prev.packing,
        [userId]: prev.packing[userId].filter((item) => item.id !== itemId),
      },
    }));
  }

  return (
    <div className="flex flex-col gap-4">
      {TRIP_DATA.passengers.map((passenger) => {
        const items = state.packing[passenger.id] ?? [];
        const packed = items.filter((i) => i.packed).length;
        const isExpanded = expandedUsers.includes(passenger.id);

        return (
          <div key={passenger.id} className="bg-card border border-border rounded-2xl overflow-hidden">
            <button
              onClick={() => toggleExpand(passenger.id)}
              className="w-full flex items-center gap-3 p-4 hover:bg-secondary/20 transition-colors"
            >
              <div className={`w-9 h-9 rounded-lg ${passenger.color} flex items-center justify-center text-sm font-bold text-primary-foreground`}>
                {passenger.avatar}
              </div>
              <div className="flex-1 text-left">
                <p className="text-sm font-semibold text-foreground">{passenger.name}</p>
                <p className="text-xs text-muted-foreground">
                  {packed}/{items.length} items packed
                </p>
              </div>
              <div className="w-12 h-1.5 bg-secondary/50 rounded-full overflow-hidden mr-2">
                <div
                  className="h-full bg-primary rounded-full transition-all"
                  style={{ width: items.length > 0 ? `${(packed / items.length) * 100}%` : "0%" }}
                />
              </div>
              {isExpanded ? (
                <ChevronDown className="w-4 h-4 text-muted-foreground" />
              ) : (
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              )}
            </button>

            {isExpanded && (
              <div className="px-4 pb-4 animate-in fade-in slide-in-from-top-1 duration-200">
                <div className="flex flex-col gap-1.5 mb-3">
                  {items.map((item) => (
                    <div
                      key={item.id}
                      className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-all ${
                        item.packed ? "opacity-50" : ""
                      }`}
                    >
                      <button
                        onClick={() => togglePacked(passenger.id, item.id)}
                        className={`w-4 h-4 rounded border-2 flex items-center justify-center shrink-0 transition-all ${
                          item.packed
                            ? "bg-primary border-primary"
                            : "border-muted-foreground/30 hover:border-primary"
                        }`}
                      >
                        {item.packed && <Check className="w-2.5 h-2.5 text-primary-foreground" />}
                      </button>
                      <span
                        className={`flex-1 text-sm ${
                          item.packed ? "line-through text-muted-foreground" : "text-foreground"
                        }`}
                      >
                        {item.item}
                      </span>
                      <button
                        onClick={() => deleteItem(passenger.id, item.id)}
                        className="p-1 text-muted-foreground hover:text-destructive transition-colors"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2">
                  <input
                    value={newItemText[passenger.id] ?? ""}
                    onChange={(e) =>
                      setNewItemText((prev) => ({ ...prev, [passenger.id]: e.target.value }))
                    }
                    onKeyDown={(e) => e.key === "Enter" && addItem(passenger.id)}
                    placeholder="Add packing item..."
                    className="flex-1 bg-secondary/30 border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
                  />
                  <button
                    onClick={() => addItem(passenger.id)}
                    className="px-3 py-2 bg-primary/10 text-primary rounded-lg text-sm font-medium hover:bg-primary/20 transition-all"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
