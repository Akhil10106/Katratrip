"use client";

import { useState } from "react";
import { TRIP_DATA } from "@/lib/trip-data";
import { useAppState, logActivity } from "@/lib/store";
import { Train, Lock, User, ArrowRight } from "lucide-react";

export function LoginScreen() {
  const [, setState] = useAppState();
  const [selectedUser, setSelectedUser] = useState<string | null>(null);
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const pins: Record<string, string> = {
    akhil: "1234",
    pratham: "1234",
    aniket: "1234",
  };

  function handleLogin() {
    if (!selectedUser) return;
    setLoading(true);
    setError("");

    setTimeout(() => {
      if (pins[selectedUser] === pin) {
        setState((prev) => ({ ...prev, currentUser: selectedUser }));
        logActivity("Logged in", selectedUser);
      } else {
        setError("Incorrect PIN. Try 1234");
      }
      setLoading(false);
    }, 800);
  }

  return (
    <div className="min-h-[100dvh] bg-background flex items-center justify-center p-4 sm:p-6">
      <div className="w-full max-w-md">
        {/* Logo and branding */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 mb-4">
            <Train className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-3xl font-bold text-foreground tracking-tight">TripSync</h1>
          <p className="text-muted-foreground mt-1 text-sm">
            {TRIP_DATA.journey.train.name} &middot; {TRIP_DATA.journey.from.code} to {TRIP_DATA.journey.to.code}
          </p>
        </div>

        {/* Login card */}
        <div className="bg-card border border-border rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-6">
            <Lock className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-foreground">Private Access</span>
          </div>

          {/* User selection */}
          <p className="text-xs uppercase tracking-wider text-muted-foreground mb-3">Select Passenger</p>
          <div className="flex flex-col gap-2 mb-6">
            {TRIP_DATA.passengers.map((p) => (
              <button
                key={p.id}
                onClick={() => { setSelectedUser(p.id); setError(""); setPin(""); }}
                className={`flex items-center gap-3 p-3 rounded-xl border transition-all duration-200 text-left ${
                  selectedUser === p.id
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-muted-foreground/30 bg-secondary/30"
                }`}
              >
                <div className={`w-10 h-10 rounded-lg ${p.color} flex items-center justify-center text-sm font-bold text-primary-foreground`}>
                  {p.avatar}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground truncate">{p.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {p.coach}/{p.berth}/{p.berthType} &middot; Age {p.age}
                  </p>
                </div>
                {selectedUser === p.id && (
                  <div className="w-2 h-2 rounded-full bg-primary" />
                )}
              </button>
            ))}
          </div>

          {/* PIN input */}
          {selectedUser && (
            <div className="animate-in fade-in slide-in-from-bottom-2 duration-300">
              <p className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Enter PIN</p>
              <div className="flex gap-2 mb-4">
                <div className="relative flex-1">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <input
                    type="password"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    autoComplete="one-time-code"
                    value={pin}
                    onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
                    onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                    placeholder="Enter 4-digit PIN"
                    maxLength={4}
                    className="w-full bg-secondary/50 border border-border rounded-xl pl-10 pr-4 py-3 text-base sm:text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
                  />
                </div>
                <button
                  onClick={handleLogin}
                  disabled={loading || pin.length < 4}
                  className="px-5 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-40 transition-all duration-200 flex items-center gap-2 text-sm font-medium touch-manipulation active:scale-95"
                >
                  {loading ? (
                    <div className="w-4 h-4 border-2 border-primary-foreground/40 border-t-primary-foreground rounded-full animate-spin" />
                  ) : (
                    <ArrowRight className="w-4 h-4" />
                  )}
                </button>
              </div>
              {error && <p className="text-xs text-destructive">{error}</p>}
              <p className="text-xs text-muted-foreground mt-2">Default PIN: 1234</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <p className="text-center text-xs text-muted-foreground mt-6">
          PNR: {TRIP_DATA.journey.pnr} &middot; {TRIP_DATA.journey.journeyDate}
        </p>
      </div>
    </div>
  );
}
