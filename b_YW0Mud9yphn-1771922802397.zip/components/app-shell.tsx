"use client";

import { useAppState } from "@/lib/store";
import { LoginScreen } from "./login-screen";
import { AppNavigation } from "./app-navigation";
import { DashboardView } from "./dashboard-view";
import { PlanningView } from "./planning-view";
import { ExpensesView } from "./expenses-view";
import { ChatView } from "./chat-view";
import { NotesView } from "./notes-view";
import { MediaView } from "./media-view";
import { Suspense, memo } from "react";
import { ErrorBoundary } from "./error-boundary";

const viewComponents: Record<string, React.ComponentType> = {
  dashboard: DashboardView,
  planning: PlanningView,
  expenses: ExpensesView,
  chat: ChatView,
  notes: NotesView,
  media: MediaView,
};

function ViewLoader() {
  return (
    <div className="flex items-center justify-center min-h-[50vh]">
      <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
    </div>
  );
}

const MemoizedView = memo(function MemoizedView({ activeTab }: { activeTab: string }) {
  const Component = viewComponents[activeTab] ?? DashboardView;
  return <Component />;
});

export function AppShell() {
  const [state] = useAppState();

  if (!state.currentUser) {
    return <LoginScreen />;
  }

  return (
    <div className="flex min-h-[100dvh] bg-background overflow-x-hidden">
      <AppNavigation />
      <main className="flex-1 min-w-0 mt-14 lg:mt-0 pb-safe">
        <div className="p-3 sm:p-4 md:p-6 lg:p-8 max-w-6xl mx-auto w-full">
          <Suspense fallback={<ViewLoader />}>
            <MemoizedView activeTab={state.activeTab} />
          </Suspense>
        </div>
      </main>
    </div>
  );
}
