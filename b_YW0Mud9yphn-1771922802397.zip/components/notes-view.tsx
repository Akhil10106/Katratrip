"use client";

import { useState } from "react";
import { useAppState, generateId, logActivity } from "@/lib/store";
import { TRIP_DATA } from "@/lib/trip-data";
import { StickyNote, Plus, Trash2, Edit3, Save, X } from "lucide-react";
import { toast } from "sonner";

export function NotesView() {
  const [state, setState] = useAppState();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newTitle, setNewTitle] = useState("");
  const [newContent, setNewContent] = useState("");

  function addNote() {
    if (!newTitle.trim() || !newContent.trim()) return;
    setState((prev) => ({
      ...prev,
      notes: [
        {
          id: generateId(),
          title: newTitle.trim(),
          content: newContent.trim(),
          author: state.currentUser!,
          updatedAt: new Date().toISOString().split("T")[0],
        },
        ...prev.notes,
      ],
    }));
    logActivity(`Created note: ${newTitle.trim()}`, state.currentUser!);
    toast.success("Note created");
    setNewTitle("");
    setNewContent("");
    setShowForm(false);
  }

  function deleteNote(id: string) {
    setState((prev) => ({
      ...prev,
      notes: prev.notes.filter((n) => n.id !== id),
    }));
    toast.success("Note deleted");
  }

  function startEditing(note: { id: string; title: string; content: string }) {
    setEditingId(note.id);
    setNewTitle(note.title);
    setNewContent(note.content);
  }

  function saveEdit() {
    if (!editingId) return;
    setState((prev) => ({
      ...prev,
      notes: prev.notes.map((n) =>
        n.id === editingId
          ? { ...n, title: newTitle.trim(), content: newContent.trim(), updatedAt: new Date().toISOString().split("T")[0] }
          : n
      ),
    }));
    toast.success("Note updated");
    setEditingId(null);
    setNewTitle("");
    setNewContent("");
  }

  function cancelEdit() {
    setEditingId(null);
    setNewTitle("");
    setNewContent("");
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="min-w-0">
          <h2 className="text-xl sm:text-2xl font-bold text-foreground">Travel Notes</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Shared notes and travel plans for the group.
          </p>
        </div>
        <button
          onClick={() => { setShowForm(!showForm); cancelEdit(); }}
          className="flex items-center justify-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-all touch-manipulation active:scale-95 w-full sm:w-auto shrink-0"
        >
          <Plus className="w-4 h-4" />
          New Note
        </button>
      </div>

      {/* Create/Edit form */}
      {(showForm || editingId) && (
        <div className="bg-card border border-primary/20 rounded-2xl p-6 animate-in fade-in slide-in-from-top-2 duration-300">
          <h3 className="text-sm font-semibold text-foreground mb-4">
            {editingId ? "Edit Note" : "New Note"}
          </h3>
          <input
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            placeholder="Note title"
            className="w-full bg-secondary/30 border border-border rounded-xl px-4 py-2.5 text-base sm:text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors mb-3"
          />
          <textarea
            value={newContent}
            onChange={(e) => setNewContent(e.target.value)}
            placeholder="Write your note..."
            rows={5}
            className="w-full bg-secondary/30 border border-border rounded-xl px-4 py-3 text-base sm:text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors resize-none leading-relaxed mb-3"
          />
          <div className="flex flex-col sm:flex-row gap-2">
            <button
              onClick={editingId ? saveEdit : addNote}
              className="flex items-center justify-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-all touch-manipulation active:scale-95"
            >
              <Save className="w-4 h-4" />
              {editingId ? "Save Changes" : "Create Note"}
            </button>
            <button
              onClick={() => { setShowForm(false); cancelEdit(); }}
              className="flex items-center justify-center gap-2 px-4 py-2.5 bg-secondary/50 text-muted-foreground rounded-xl text-sm font-medium hover:text-foreground transition-all touch-manipulation"
            >
              <X className="w-4 h-4" />
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Notes grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {state.notes.map((note) => {
          const author = TRIP_DATA.passengers.find((p) => p.id === note.author);
          return (
            <div key={note.id} className="bg-card border border-border rounded-2xl p-4 sm:p-5 group hover:border-muted-foreground/30 transition-all">
              <div className="flex items-start justify-between mb-3 gap-2">
                <h3 className="text-base font-semibold text-foreground min-w-0 break-words">{note.title}</h3>
                <div className="flex gap-1 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity shrink-0">
                  <button
                    onClick={() => startEditing(note)}
                    className="p-1.5 text-muted-foreground hover:text-primary transition-colors touch-manipulation"
                  >
                    <Edit3 className="w-4 h-4 sm:w-3.5 sm:h-3.5" />
                  </button>
                  <button
                    onClick={() => deleteNote(note.id)}
                    className="p-1.5 text-muted-foreground hover:text-destructive transition-colors touch-manipulation"
                  >
                    <Trash2 className="w-4 h-4 sm:w-3.5 sm:h-3.5" />
                  </button>
                </div>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-line mb-4">
                {note.content}
              </p>
              <div className="flex items-center gap-2 pt-3 border-t border-border">
                <div className={`w-5 h-5 rounded-md ${author?.color ?? "bg-muted"} flex items-center justify-center`}>
                  <span className="text-[8px] font-bold text-primary-foreground">
                    {author?.avatar?.charAt(0) ?? "?"}
                  </span>
                </div>
                <span className="text-[10px] text-muted-foreground">
                  {author?.name.split(" ")[0] ?? "Unknown"} &middot; {note.updatedAt}
                </span>
              </div>
            </div>
          );
        })}
        {state.notes.length === 0 && (
          <div className="col-span-full bg-card border border-border rounded-2xl p-12 text-center">
            <StickyNote className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">No notes yet. Create one to share travel plans!</p>
          </div>
        )}
      </div>
    </div>
  );
}
