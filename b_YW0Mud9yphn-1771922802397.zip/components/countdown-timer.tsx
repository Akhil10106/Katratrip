"use client";

import { useState, useEffect } from "react";
import { TRIP_DATA } from "@/lib/trip-data";
import { Clock, Flame } from "lucide-react";

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  total: number;
}

function calcTimeLeft(): TimeLeft {
  const target = new Date(`${TRIP_DATA.journey.journeyDate}T${TRIP_DATA.journey.departureTime}:00+05:30`).getTime();
  const now = Date.now();
  const diff = target - now;

  if (diff <= 0) return { days: 0, hours: 0, minutes: 0, seconds: 0, total: 0 };

  return {
    days: Math.floor(diff / (1000 * 60 * 60 * 24)),
    hours: Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
    minutes: Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)),
    seconds: Math.floor((diff % (1000 * 60)) / 1000),
    total: diff,
  };
}

function getMilestoneAlert(days: number): string | null {
  if (days <= 0) return "Journey day is here!";
  if (days === 1) return "Departing tomorrow!";
  if (days <= 7) return "Less than a week to go!";
  if (days <= 30) return "Less than a month away!";
  return null;
}

export function CountdownTimer() {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>(calcTimeLeft());

  useEffect(() => {
    const interval = setInterval(() => setTimeLeft(calcTimeLeft()), 1000);
    return () => clearInterval(interval);
  }, []);

  const milestone = getMilestoneAlert(timeLeft.days);
  const units = [
    { label: "Days", value: timeLeft.days },
    { label: "Hours", value: timeLeft.hours },
    { label: "Minutes", value: timeLeft.minutes },
    { label: "Seconds", value: timeLeft.seconds },
  ];

  return (
    <div className="bg-card border border-border rounded-2xl p-6 relative overflow-hidden">
      {/* Subtle glow effect */}
      <div className="absolute -top-20 -right-20 w-40 h-40 bg-primary/5 rounded-full blur-3xl" />

      <div className="relative">
        <div className="flex items-center gap-2 mb-4">
          <Clock className="w-4 h-4 text-primary" />
          <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Departure Countdown
          </span>
        </div>

        {/* Countdown digits */}
        <div className="grid grid-cols-4 gap-2 sm:gap-3">
          {units.map((unit) => (
            <div key={unit.label} className="text-center">
              <div className="bg-secondary/50 border border-border rounded-xl p-2 sm:p-3 mb-1.5">
                <span className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground font-mono tabular-nums">
                  {String(unit.value).padStart(2, "0")}
                </span>
              </div>
              <span className="text-[9px] sm:text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
                {unit.label}
              </span>
            </div>
          ))}
        </div>

        {/* Milestone alert */}
        {milestone && (
          <div className="mt-4 flex items-center gap-2 px-3 py-2 rounded-xl bg-primary/5 border border-primary/10">
            <Flame className="w-4 h-4 text-primary shrink-0" />
            <span className="text-xs font-medium text-primary">{milestone}</span>
          </div>
        )}
      </div>
    </div>
  );
}
