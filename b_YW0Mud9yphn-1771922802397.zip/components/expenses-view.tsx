"use client";

import { useState } from "react";
import { useAppState, generateId, logActivity } from "@/lib/store";
import { TRIP_DATA } from "@/lib/trip-data";
import { DollarSign, Plus, Trash2, TrendingUp, ArrowUpDown, Users } from "lucide-react";
import { toast } from "sonner";

export function ExpensesView() {
  const [state, setState] = useAppState();
  const [showForm, setShowForm] = useState(false);
  const [desc, setDesc] = useState("");
  const [amount, setAmount] = useState("");
  const [paidBy, setPaidBy] = useState(state.currentUser ?? "akhil");

  const totalExpenses = state.expenses.reduce((sum, e) => sum + e.amount, 0);

  // Calculate balances
  const balances: Record<string, number> = { akhil: 0, pratham: 0, aniket: 0 };
  state.expenses.forEach((exp) => {
    const splitAmount = exp.amount / exp.splitWith.length;
    balances[exp.paidBy] += exp.amount;
    exp.splitWith.forEach((userId) => {
      balances[userId] -= splitAmount;
    });
  });

  function addExpense() {
    if (!desc.trim() || !amount) return;
    setState((prev) => ({
      ...prev,
      expenses: [
        ...prev.expenses,
        {
          id: generateId(),
          description: desc.trim(),
          amount: parseFloat(amount),
          paidBy,
          splitWith: ["akhil", "pratham", "aniket"],
          date: new Date().toISOString().split("T")[0],
        },
      ],
    }));
    logActivity(`Added expense: ${desc.trim()} - Rs.${amount}`, state.currentUser!);
    toast.success("Expense added");
    setDesc("");
    setAmount("");
    setShowForm(false);
  }

  function deleteExpense(id: string) {
    setState((prev) => ({
      ...prev,
      expenses: prev.expenses.filter((e) => e.id !== id),
    }));
    toast.success("Expense removed");
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="min-w-0">
          <h2 className="text-xl sm:text-2xl font-bold text-foreground">Expense Tracker</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Track and split expenses among all passengers.
          </p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center justify-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-all touch-manipulation active:scale-95 shrink-0 w-full sm:w-auto"
        >
          <Plus className="w-4 h-4" />
          Add Expense
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-card border border-border rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-4 h-4 text-primary" />
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              Total Spent
            </span>
          </div>
          <p className="text-2xl font-bold text-foreground font-mono tabular-nums">
            {"₹"}{totalExpenses.toFixed(2)}
          </p>
        </div>
        <div className="bg-card border border-border rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <ArrowUpDown className="w-4 h-4 text-chart-2" />
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              Per Person
            </span>
          </div>
          <p className="text-2xl font-bold text-foreground font-mono tabular-nums">
            {"₹"}{(totalExpenses / 3).toFixed(2)}
          </p>
        </div>
        <div className="bg-card border border-border rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <Users className="w-4 h-4 text-chart-3" />
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              Transactions
            </span>
          </div>
          <p className="text-2xl font-bold text-foreground font-mono tabular-nums">
            {state.expenses.length}
          </p>
        </div>
      </div>

      {/* Balance cards */}
      <div className="bg-card border border-border rounded-2xl p-6">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">
          Settlement Summary
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {TRIP_DATA.passengers.map((p) => {
            const balance = balances[p.id];
            const isPositive = balance > 0;
            return (
              <div key={p.id} className="flex items-center gap-3 p-3 rounded-xl bg-secondary/20 border border-border/50">
                <div className={`w-9 h-9 rounded-lg ${p.color} flex items-center justify-center text-sm font-bold text-primary-foreground shrink-0`}>
                  {p.avatar}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">{p.name.split(" ")[0]}</p>
                  <p className={`text-sm font-bold font-mono tabular-nums ${
                    isPositive ? "text-success" : balance < 0 ? "text-destructive" : "text-muted-foreground"
                  }`}>
                    {isPositive ? "+" : ""}{"₹"}{balance.toFixed(2)}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
        <p className="text-[10px] text-muted-foreground mt-3">
          Positive = others owe you. Negative = you owe others.
        </p>
      </div>

      {/* Add expense form */}
      {showForm && (
        <div className="bg-card border border-primary/20 rounded-2xl p-6 animate-in fade-in slide-in-from-top-2 duration-300">
          <h3 className="text-sm font-semibold text-foreground mb-4">New Expense</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 mb-4">
            <input
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
              placeholder="Description"
              className="bg-secondary/30 border border-border rounded-xl px-4 py-2.5 text-base sm:text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
            />
            <input
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Amount (Rs.)"
              type="number"
              inputMode="decimal"
              className="bg-secondary/30 border border-border rounded-xl px-4 py-2.5 text-base sm:text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
            />
            <select
              value={paidBy}
              onChange={(e) => setPaidBy(e.target.value)}
              className="bg-secondary/30 border border-border rounded-xl px-4 py-2.5 text-base sm:text-sm text-foreground focus:outline-none focus:border-primary transition-colors"
            >
              {TRIP_DATA.passengers.map((p) => (
                <option key={p.id} value={p.id}>{p.name.split(" ")[0]} paid</option>
              ))}
            </select>
          </div>
          <div className="flex gap-2">
            <button
              onClick={addExpense}
              className="px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-all touch-manipulation active:scale-95"
            >
              Add Expense
            </button>
            <button
              onClick={() => setShowForm(false)}
              className="px-4 py-2.5 bg-secondary/50 text-muted-foreground rounded-xl text-sm font-medium hover:text-foreground transition-all touch-manipulation"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Expense list */}
      <div className="bg-card border border-border rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-border">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            All Expenses
          </h3>
        </div>
        <div className="divide-y divide-border">
          {state.expenses.map((exp) => {
            const payer = TRIP_DATA.passengers.find((p) => p.id === exp.paidBy);
            return (
              <div key={exp.id} className="flex items-center gap-2 sm:gap-3 p-3 sm:p-4 hover:bg-secondary/10 transition-colors">
                <div className={`w-8 h-8 sm:w-9 sm:h-9 rounded-lg ${payer?.color ?? "bg-muted"} flex items-center justify-center text-xs sm:text-sm font-bold text-primary-foreground shrink-0`}>
                  {payer?.avatar ?? "?"}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{exp.description}</p>
                  <p className="text-xs text-muted-foreground truncate">
                    Paid by {payer?.name.split(" ")[0]} &middot; {exp.date} &middot; Split {exp.splitWith.length} ways
                  </p>
                </div>
                <p className="text-sm font-bold text-foreground font-mono tabular-nums shrink-0">
                  {"₹"}{exp.amount.toFixed(2)}
                </p>
                <button
                  onClick={() => deleteExpense(exp.id)}
                  className="p-1.5 text-muted-foreground hover:text-destructive transition-colors shrink-0 touch-manipulation"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
          {state.expenses.length === 0 && (
            <div className="p-8 text-center">
              <DollarSign className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">No expenses yet</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
