"use client";

import { useState, useRef } from "react";
import { useAppState, generateId, logActivity } from "@/lib/store";
import { TRIP_DATA } from "@/lib/trip-data";
import { Image as ImageIcon, Plus, Trash2, Camera, X, Calendar, Upload } from "lucide-react";
import { toast } from "sonner";

export function MediaView() {
  const [state, setState] = useAppState();
  const [showUpload, setShowUpload] = useState(false);
  const [caption, setCaption] = useState("");
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      setPreviewUrl(event.target?.result as string);
      setShowUpload(true);
    };
    reader.readAsDataURL(file);
  }

  function uploadMedia() {
    if (!previewUrl) return;
    setState((prev) => ({
      ...prev,
      media: [
        {
          id: generateId(),
          url: previewUrl!,
          type: "photo",
          caption: caption.trim() || "Trip photo",
          uploadedBy: state.currentUser!,
          uploadedAt: new Date().toISOString(),
        },
        ...prev.media,
      ],
    }));
    logActivity("Uploaded a photo", state.currentUser!);
    toast.success("Photo uploaded!");
    setPreviewUrl(null);
    setCaption("");
    setShowUpload(false);
  }

  function deleteMedia(id: string) {
    setState((prev) => ({
      ...prev,
      media: prev.media.filter((m) => m.id !== id),
    }));
    toast.success("Photo removed");
  }

  // Group by date
  const grouped: Record<string, typeof state.media> = {};
  state.media.forEach((item) => {
    const date = new Date(item.uploadedAt).toLocaleDateString("en-IN", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
    if (!grouped[date]) grouped[date] = [];
    grouped[date].push(item);
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="min-w-0">
          <h2 className="text-xl sm:text-2xl font-bold text-foreground">Trip Gallery</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Upload and share trip memories with the group.
          </p>
        </div>
        <div className="flex gap-2">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleFileSelect}
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-all touch-manipulation active:scale-95 w-full sm:w-auto"
          >
            <Upload className="w-4 h-4" />
            Upload Photo
          </button>
        </div>
      </div>

      {/* Upload preview */}
      {showUpload && previewUrl && (
        <div className="bg-card border border-primary/20 rounded-2xl p-4 sm:p-6 animate-in fade-in slide-in-from-top-2 duration-300">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="w-full sm:w-32 h-48 sm:h-32 rounded-xl overflow-hidden bg-secondary/30 shrink-0">
              <img src={previewUrl} alt="Preview" className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 flex flex-col gap-3">
              <input
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                placeholder="Add a caption..."
                className="bg-secondary/30 border border-border rounded-xl px-4 py-2.5 text-base sm:text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
              />
              <div className="flex gap-2">
                <button
                  onClick={uploadMedia}
                  className="flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-all touch-manipulation active:scale-95"
                >
                  <Camera className="w-4 h-4" />
                  Upload
                </button>
                <button
                  onClick={() => { setShowUpload(false); setPreviewUrl(null); }}
                  className="flex items-center gap-2 px-4 py-2.5 bg-secondary/50 text-muted-foreground rounded-xl text-sm font-medium hover:text-foreground transition-all touch-manipulation"
                >
                  <X className="w-4 h-4" />
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Timeline */}
      {Object.entries(grouped).map(([date, items]) => (
        <div key={date}>
          <div className="flex items-center gap-2 mb-3">
            <Calendar className="w-4 h-4 text-primary" />
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{date}</h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {items.map((item) => {
              const uploader = TRIP_DATA.passengers.find((p) => p.id === item.uploadedBy);
              return (
                <div
                  key={item.id}
                  className="group relative bg-card border border-border rounded-xl overflow-hidden cursor-pointer hover:border-muted-foreground/30 transition-all"
                  onClick={() => setSelectedImage(item.id)}
                >
                  <div className="aspect-square">
                    <img src={item.url} alt={item.caption} className="w-full h-full object-cover" />
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="absolute bottom-0 left-0 right-0 p-3">
                      <p className="text-xs font-medium text-foreground truncate">{item.caption}</p>
                      <div className="flex items-center gap-1.5 mt-1">
                        <div className={`w-4 h-4 rounded-sm ${uploader?.color ?? "bg-muted"} flex items-center justify-center`}>
                          <span className="text-[7px] font-bold text-primary-foreground">
                            {uploader?.avatar?.charAt(0)}
                          </span>
                        </div>
                        <span className="text-[10px] text-muted-foreground">
                          {uploader?.name.split(" ")[0]}
                        </span>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); deleteMedia(item.id); }}
                    className="absolute top-2 right-2 p-1.5 bg-background/80 rounded-lg text-muted-foreground hover:text-destructive opacity-0 group-hover:opacity-100 transition-all"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      ))}

      {/* Empty state */}
      {state.media.length === 0 && (
        <div className="bg-card border border-border rounded-2xl p-16 text-center">
          <ImageIcon className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <h3 className="text-base font-semibold text-foreground mb-1">No photos yet</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Upload your first trip photo to start the gallery.
          </p>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-all"
          >
            <Plus className="w-4 h-4" />
            Upload Photo
          </button>
        </div>
      )}

      {/* Lightbox */}
      {selectedImage && (() => {
        const item = state.media.find((m) => m.id === selectedImage);
        if (!item) return null;
        const uploader = TRIP_DATA.passengers.find((p) => p.id === item.uploadedBy);
        return (
          <div
            className="fixed inset-0 z-50 bg-background/90 backdrop-blur-lg flex items-center justify-center p-3 sm:p-4"
            onClick={() => setSelectedImage(null)}
          >
            <div className="max-w-3xl w-full" onClick={(e) => e.stopPropagation()}>
              <div className="rounded-2xl overflow-hidden border border-border bg-card">
                <img src={item.url} alt={item.caption} className="w-full max-h-[60dvh] sm:max-h-[70vh] object-contain bg-secondary/20" />
                <div className="p-3 sm:p-4 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{item.caption}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      By {uploader?.name.split(" ")[0]} &middot;{" "}
                      {new Date(item.uploadedAt).toLocaleDateString("en-IN")}
                    </p>
                  </div>
                  <button
                    onClick={() => setSelectedImage(null)}
                    className="p-2 text-muted-foreground hover:text-foreground transition-colors touch-manipulation shrink-0"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}
