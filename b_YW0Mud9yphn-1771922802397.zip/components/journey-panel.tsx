"use client";

import { TRIP_DATA } from "@/lib/trip-data";
import { Train, MapPin, ArrowRight, Calendar, Route, Ticket, Shield } from "lucide-react";

export function JourneyPanel() {
  const { journey } = TRIP_DATA;

  return (
    <div className="bg-card border border-border rounded-2xl p-6">
      <div className="flex items-center gap-2 mb-5">
        <Train className="w-4 h-4 text-primary" />
        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Train Information
        </span>
      </div>

      {/* Route display */}
      <div className="flex items-center gap-2 sm:gap-4 mb-6">
        <div className="flex-1 min-w-0">
          <p className="text-xs text-muted-foreground mb-1">From</p>
          <p className="text-base sm:text-lg font-bold text-foreground">{journey.from.code}</p>
          <p className="text-[10px] sm:text-xs text-muted-foreground truncate">{journey.from.name}</p>
          <p className="text-sm font-semibold text-primary mt-1">{journey.departureTime}</p>
        </div>

        <div className="flex flex-col items-center gap-1 px-1 sm:px-2 shrink-0">
          <div className="text-[10px] text-muted-foreground font-medium">{journey.duration}</div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-primary" />
            <div className="w-10 sm:w-16 h-px bg-border relative">
              <ArrowRight className="w-3 h-3 text-primary absolute -right-1.5 -top-1.5" />
            </div>
            <div className="w-2 h-2 rounded-full border-2 border-primary" />
          </div>
          <div className="text-[10px] text-muted-foreground font-medium">{journey.distance}</div>
        </div>

        <div className="flex-1 text-right min-w-0">
          <p className="text-xs text-muted-foreground mb-1">To</p>
          <p className="text-base sm:text-lg font-bold text-foreground">{journey.to.code}</p>
          <p className="text-[10px] sm:text-xs text-muted-foreground truncate">{journey.to.name}</p>
          <p className="text-sm font-semibold text-primary mt-1">{journey.arrivalTime}</p>
        </div>
      </div>

      {/* Info grid */}
      <div className="grid grid-cols-2 gap-2 sm:gap-3">
        <InfoBadge icon={Train} label="Train" value={`${journey.train.number} / ${journey.train.name}`} />
        <InfoBadge icon={Ticket} label="Class" value={journey.class} />
        <InfoBadge icon={Calendar} label="Date" value={formatDate(journey.journeyDate)} />
        <InfoBadge icon={Route} label="PNR" value={journey.pnr} mono />
        <InfoBadge icon={Shield} label="Status" value={journey.status} status />
      </div>
    </div>
  );
}

function InfoBadge({
  icon: Icon,
  label,
  value,
  mono,
  status,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  mono?: boolean;
  status?: boolean;
}) {
  return (
    <div className="bg-secondary/30 rounded-xl px-3 py-2.5 border border-border/50">
      <div className="flex items-center gap-1.5 mb-1">
        <Icon className="w-3 h-3 text-muted-foreground" />
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</span>
      </div>
      <p className={`text-sm font-semibold ${status ? "text-success" : "text-foreground"} ${mono ? "font-mono" : ""} truncate`}>
        {value}
      </p>
    </div>
  );
}

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}
