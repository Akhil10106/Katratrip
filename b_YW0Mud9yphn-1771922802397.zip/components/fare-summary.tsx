"use client";

import { TRIP_DATA } from "@/lib/trip-data";
import { IndianRupee, Receipt } from "lucide-react";

export function FareSummary() {
  const { transaction } = TRIP_DATA;
  const perPerson = (transaction.totalPaid / 3).toFixed(2);

  const items = [
    { label: "Ticket Fare (3 pax)", value: transaction.ticketFare },
    { label: "IRCTC Convenience Fee", value: transaction.convenienceFee },
    { label: "Travel Insurance", value: transaction.travelInsurance },
  ];

  return (
    <div className="bg-card border border-border rounded-2xl p-6">
      <div className="flex items-center gap-2 mb-5">
        <Receipt className="w-4 h-4 text-primary" />
        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Fare Summary
        </span>
      </div>

      <div className="flex flex-col gap-2.5 mb-4">
        {items.map((item) => (
          <div key={item.label} className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">{item.label}</span>
            <span className="text-sm text-foreground font-mono tabular-nums">
              {"₹"}{item.value.toFixed(2)}
            </span>
          </div>
        ))}
      </div>

      <div className="border-t border-border pt-3 mb-3">
        <div className="flex items-center justify-between">
          <span className="text-sm font-semibold text-foreground">Total Paid</span>
          <div className="flex items-center gap-1">
            <IndianRupee className="w-4 h-4 text-primary" />
            <span className="text-lg font-bold text-primary font-mono tabular-nums">
              {transaction.totalPaid.toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      <div className="bg-secondary/30 rounded-xl px-3 py-2.5 border border-border/50">
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">Per Person</span>
          <span className="text-sm font-semibold text-foreground font-mono tabular-nums">
            {"₹"}{perPerson}
          </span>
        </div>
      </div>

      <p className="text-[10px] text-muted-foreground mt-3 font-mono">
        TXN: {transaction.id}
      </p>
    </div>
  );
}
