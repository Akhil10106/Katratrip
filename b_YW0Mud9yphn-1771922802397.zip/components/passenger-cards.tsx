"use client";

import { TRIP_DATA } from "@/lib/trip-data";
import { useAppState } from "@/lib/store";
import { Users, CheckCircle2 } from "lucide-react";

export function PassengerCards() {
  const [state] = useAppState();

  return (
    <div className="bg-card border border-border rounded-2xl p-6">
      <div className="flex items-center gap-2 mb-5">
        <Users className="w-4 h-4 text-primary" />
        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Passengers
        </span>
        <span className="ml-auto text-xs text-muted-foreground font-mono">
          Coach {TRIP_DATA.passengers[0].coach}
        </span>
      </div>

      <div className="flex flex-col gap-3">
        {TRIP_DATA.passengers.map((p) => {
          const isCurrentUser = p.id === state.currentUser;
          return (
            <div
              key={p.id}
              className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                isCurrentUser
                  ? "border-primary/30 bg-primary/5"
                  : "border-border bg-secondary/20"
              }`}
            >
              <div className={`w-10 h-10 rounded-lg ${p.color} flex items-center justify-center text-sm font-bold text-primary-foreground shrink-0`}>
                {p.avatar}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-semibold text-foreground truncate">{p.name}</p>
                  {isCurrentUser && (
                    <span className="text-[10px] bg-primary/10 text-primary px-1.5 py-0.5 rounded-full font-medium shrink-0">
                      You
                    </span>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  Age {p.age} &middot; {p.gender === "M" ? "Male" : "Female"}
                </p>
              </div>
              <div className="text-right shrink-0">
                <div className="flex items-center gap-1 mb-0.5">
                  <CheckCircle2 className="w-3 h-3 text-success" />
                  <span className="text-xs font-semibold text-success">{p.status}</span>
                </div>
                <p className="text-xs text-muted-foreground font-mono">
                  {p.berth}/{p.berthType}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
