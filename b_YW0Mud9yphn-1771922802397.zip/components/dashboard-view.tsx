"use client";

import { CountdownTimer } from "./countdown-timer";
import { JourneyPanel } from "./journey-panel";
import { PassengerCards } from "./passenger-cards";
import { FareSummary } from "./fare-summary";
import { RouteTimeline } from "./route-timeline";
import { ActivityFeed } from "./activity-feed";
import { useAppState } from "@/lib/store";
import { TRIP_DATA } from "@/lib/trip-data";

export function DashboardView() {
  const [state] = useAppState();
  const currentPassenger = TRIP_DATA.passengers.find((p) => p.id === state.currentUser);
  const checklistDone = state.checklist.filter((c) => c.completed).length;
  const packingItems = state.packing[state.currentUser ?? "akhil"] ?? [];
  const packedCount = packingItems.filter((p) => p.packed).length;

  return (
    <div className="space-y-6">
      {/* Welcome banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="min-w-0">
          <h2 className="text-xl sm:text-2xl font-bold text-foreground text-balance">
            Welcome back, {currentPassenger?.name.split(" ")[0]}
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Your journey to Vaishno Devi is coming up. Here{"'"}s your trip overview.
          </p>
        </div>
        <div className="flex items-center gap-2 sm:gap-3 overflow-x-auto">
          <QuickStat label="Tasks" value={`${checklistDone}/${state.checklist.length}`} />
          <QuickStat label="Packed" value={`${packedCount}/${packingItems.length}`} />
          <QuickStat label="Messages" value={String(state.messages.length)} />
        </div>
      </div>

      {/* Main grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <CountdownTimer />
        <JourneyPanel />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <PassengerCards />
        <FareSummary />
        <RouteTimeline />
      </div>

      <ActivityFeed />
    </div>
  );
}

function QuickStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-card border border-border rounded-xl px-3 sm:px-4 py-2 sm:py-2.5 text-center shrink-0">
      <p className="text-base sm:text-lg font-bold text-foreground font-mono tabular-nums">{value}</p>
      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
    </div>
  );
}
