"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { useAppState, generateId, logActivity } from "@/lib/store";
import { TRIP_DATA } from "@/lib/trip-data";
import { MessageSquare, Send } from "lucide-react";

export function ChatView() {
  const [state, setState] = useAppState();
  const [message, setMessage] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const currentPassenger = TRIP_DATA.passengers.find((p) => p.id === state.currentUser);

  useEffect(() => {
    if (scrollRef.current) {
      requestAnimationFrame(() => {
        scrollRef.current?.scrollTo({ top: scrollRef.current!.scrollHeight, behavior: "smooth" });
      });
    }
  }, [state.messages.length]);

  function sendMessage() {
    if (!message.trim() || !state.currentUser) return;
    setState((prev) => ({
      ...prev,
      messages: [
        ...prev.messages,
        {
          id: generateId(),
          userId: state.currentUser!,
          userName: currentPassenger?.name.split(" ")[0] ?? "User",
          text: message.trim(),
          timestamp: new Date().toISOString(),
        },
      ],
    }));
    setMessage("");
  }

  // Group messages by date
  const groupedMessages: { date: string; messages: typeof state.messages }[] = [];
  state.messages.forEach((msg) => {
    const date = new Date(msg.timestamp).toLocaleDateString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric",
    });
    const lastGroup = groupedMessages[groupedMessages.length - 1];
    if (lastGroup?.date === date) {
      lastGroup.messages.push(msg);
    } else {
      groupedMessages.push({ date, messages: [msg] });
    }
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Group Chat</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Private conversation between trip members.
        </p>
      </div>

      <div className="bg-card border border-border rounded-2xl flex flex-col h-[calc(100dvh-14rem)] sm:h-[calc(100dvh-15rem)] lg:h-[calc(100dvh-13rem)]">
        {/* Header */}
        <div className="flex items-center gap-3 p-4 border-b border-border shrink-0">
          <MessageSquare className="w-4 h-4 text-primary" />
          <span className="text-sm font-semibold text-foreground">Trip Group</span>
          <div className="ml-auto flex -space-x-2">
            {TRIP_DATA.passengers.map((p) => (
              <div
                key={p.id}
                className={`w-7 h-7 rounded-full ${p.color} flex items-center justify-center text-[9px] font-bold text-primary-foreground border-2 border-card`}
              >
                {p.avatar.charAt(0)}
              </div>
            ))}
          </div>
        </div>

        {/* Messages */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4">
          {groupedMessages.map((group) => (
            <div key={group.date}>
              {/* Date divider */}
              <div className="flex items-center gap-3 my-4">
                <div className="flex-1 h-px bg-border" />
                <span className="text-[10px] text-muted-foreground font-medium px-2">{group.date}</span>
                <div className="flex-1 h-px bg-border" />
              </div>

              {group.messages.map((msg) => {
                const isMe = msg.userId === state.currentUser;
                const passenger = TRIP_DATA.passengers.find((p) => p.id === msg.userId);
                const time = new Date(msg.timestamp).toLocaleTimeString("en-IN", {
                  hour: "2-digit",
                  minute: "2-digit",
                });

                return (
                  <div key={msg.id} className={`flex gap-3 mb-3 ${isMe ? "flex-row-reverse" : ""}`}>
                    {!isMe && (
                      <div className={`w-8 h-8 rounded-lg ${passenger?.color ?? "bg-muted"} flex items-center justify-center text-[10px] font-bold text-primary-foreground shrink-0`}>
                        {passenger?.avatar?.charAt(0) ?? "?"}
                      </div>
                    )}
                    <div className={`max-w-[85%] sm:max-w-[75%] ${isMe ? "items-end" : "items-start"}`}>
                      {!isMe && (
                        <p className="text-[10px] text-muted-foreground font-medium mb-1 px-1">
                          {msg.userName}
                        </p>
                      )}
                      <div
                        className={`px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${
                          isMe
                            ? "bg-primary text-primary-foreground rounded-br-md"
                            : "bg-secondary/50 text-foreground border border-border rounded-bl-md"
                        }`}
                      >
                        {msg.text}
                      </div>
                      <p className={`text-[10px] text-muted-foreground mt-1 px-1 ${isMe ? "text-right" : ""}`}>
                        {time}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          ))}

          {state.messages.length === 0 && (
            <div className="flex-1 flex items-center justify-center h-full">
              <div className="text-center">
                <MessageSquare className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">No messages yet. Start the conversation!</p>
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <div className="p-3 sm:p-4 border-t border-border shrink-0">
          <div className="flex items-center gap-2">
            <input
              ref={inputRef}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && (e.preventDefault(), sendMessage())}
              placeholder="Type a message..."
              className="flex-1 bg-secondary/30 border border-border rounded-xl px-4 py-2.5 text-base sm:text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
            />
            <button
              onClick={sendMessage}
              disabled={!message.trim()}
              className="p-2.5 bg-primary text-primary-foreground rounded-xl hover:bg-primary/90 disabled:opacity-40 transition-all touch-manipulation active:scale-95 shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
