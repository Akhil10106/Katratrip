"use client";

import { TRIP_DATA } from "@/lib/trip-data";
import { MapPin } from "lucide-react";

export function RouteTimeline() {
  const { route } = TRIP_DATA;

  return (
    <div className="bg-card border border-border rounded-2xl p-6">
      <div className="flex items-center gap-2 mb-5">
        <MapPin className="w-4 h-4 text-primary" />
        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Route Map
        </span>
      </div>

      <div className="relative">
        {route.map((stop, index) => {
          const isFirst = index === 0;
          const isLast = index === route.length - 1;

          return (
            <div key={stop.station} className="flex gap-4 relative">
              {/* Timeline line */}
              <div className="flex flex-col items-center">
                <div
                  className={`w-3 h-3 rounded-full shrink-0 ${
                    isFirst || isLast ? "bg-primary" : "bg-muted-foreground/40 border-2 border-card"
                  }`}
                />
                {!isLast && <div className="w-px flex-1 bg-border min-h-8" />}
              </div>

              {/* Station info */}
              <div className={`pb-4 flex-1 min-w-0 ${isLast ? "pb-0" : ""}`}>
                <div className="flex items-start justify-between gap-1 sm:gap-2">
                  <div className="min-w-0 flex-1">
                    <p className={`text-xs sm:text-sm font-medium truncate ${isFirst || isLast ? "text-foreground" : "text-muted-foreground"}`}>
                      {stop.station}
                    </p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      Day {stop.day} &middot; {stop.distance}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    {stop.arrival !== "--" && (
                      <p className="text-[10px] sm:text-xs text-muted-foreground font-mono">{stop.arrival}</p>
                    )}
                    {stop.departure !== "--" && (
                      <p className="text-[10px] sm:text-xs font-semibold text-foreground font-mono">{stop.departure}</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
